#include <iostream>

#include "tamagotchi.h"

using namespace std;

int main()
{
    Tamagotchi miTamagotchi;
    miTamagotchi.menu();

    return 0;
}